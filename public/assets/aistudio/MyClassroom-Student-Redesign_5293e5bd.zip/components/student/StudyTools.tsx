import React, { useEffect, useState } from 'react';
import { BookOpen, CheckCircle2, ClipboardCheck, Loader2, Sparkles, ArrowRight, Trophy, ChevronDown } from 'lucide-react';
import confetti from 'canvas-confetti';
import { supabase } from '../../lib/supabase';
import { Badge, Button, Card, EmptyState, Field, IconTile, LoadingStages, SegmentedControl, Skeleton } from './UI';
import { NotesReader } from './NotesReader';

type Persist = (kind: 'NOTE' | 'TEST' | 'RESULT', title: string, content: unknown) => Promise<void>;
type Question = { id: number; text: string; type: string; options?: string[]; correctAnswer?: string; modelAnswer?: string; explanation?: string; marks?: number };
type GeneratedTest = { title: string; subject: string; questions: Question[] };

async function postAI<T>(route: string, input: object): Promise<T> {
  const { data: { session } } = await supabase.auth.getSession();
  const base=(import.meta.env.VITE_API_BASE_URL||'').replace(/\/$/,'');
  const response = await fetch(`${base}${route}`, { method: 'POST', headers: {
    'Content-Type': 'application/json', ...(session ? { Authorization: `Bearer ${session.access_token}` } : {})
  }, body: JSON.stringify(input) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'AI service unavailable. Check your server key.');
  return data as T;
}

export function SmartNotes({ save }: { save: Persist }) {
  const [topic, setTopic] = useState('');
  const [level, setLevel] = useState('College');
  const [detail, setDetail] = useState('Detailed');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const [stage,setStage]=useState(0);
  const [subjectStyle,setSubjectStyle]=useState('Conceptual');
  useEffect(()=>{if(!busy)return;setStage(0);const tick=setInterval(()=>setStage(v=>Math.min(2,v+1)),2500);return()=>clearInterval(tick);},[busy]);

  async function generate(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(''); setSaved(false);
    try {
      // Hinglish: Fake predefined definition ki jagah actual structured AI notes generate honge.
      const requestedTopic=`${topic.trim()} (Teaching emphasis: ${subjectStyle})`.slice(0,500);
      const result = await postAI<{ content: string }>('/api/gemini/generate-notes', { topic:requestedTopic, gradeLevel: level, detailLevel: detail });
      if (!result.content || result.content.length < (detail==='Revision'?120:300)) throw new Error('Incomplete notes received. Please retry.');
      setNotes(result.content);
      await save('NOTE', topic.trim(), { markdown: result.content, level, detail });
      setStage(3);
      setSaved(true);
    } catch (err) { setError((err as Error).message); }
    finally { setBusy(false); }
  }

  return <div className="space-y-6 feature-notes">
    <div className="section-heading"><IconTile feature="notes"><BookOpen/></IconTile><div><Badge feature="notes">LEARNING STUDIO</Badge><h1>Notes that actually teach.</h1><p>Clear explanations, visual structure, formulas, worked examples and exam-ready revision.</p></div></div>
    <div className="notes-studio-grid"><form onSubmit={generate} className="notes-studio-form"><Card feature="notes" className="space-y-6"><div><h2 className="text-xl font-extrabold">Create your lesson</h2><p className="text-sm text-slate-500 mt-1">Tell us what you want to understand.</p></div>
      <Field label="Topic or instructions"><textarea value={topic} onChange={e=>setTopic(e.target.value)} rows={5} required maxLength={470} placeholder="e.g. Explain 8085 interrupts, their priority, masking, and worked assembly examples"/></Field>
      <Field label="Your level"><SegmentedControl feature="notes" values={['School','College','Competitive exam']} value={level} onChange={setLevel}/></Field>
      <Field label="Notes depth"><SegmentedControl feature="notes" values={['Revision','Detailed','Comprehensive']} value={detail} onChange={setDetail}/></Field>
      <Field label="Subject style (optional)"><div className="flex flex-wrap gap-2">{['Conceptual','Technical','Exam focus','Examples'].map(s=><button type="button" key={s} className={`ui-choice-chip ${subjectStyle===s?'selected':''}`} onClick={()=>setSubjectStyle(s)}>{s}</button>)}</div></Field>
      <Button feature="notes" type="submit" disabled={busy||!topic.trim()} className="w-full">{busy?<Loader2 className="animate-spin"/>:<Sparkles size={18}/>} {busy?'Crafting your lesson…':'Generate premium notes'} <ArrowRight size={17}/></Button>
      <p className="text-xs text-slate-400 text-center">Saved automatically to your private library</p>
    </Card></form>
    <div className="min-w-0 space-y-4">{busy&&<Card feature="notes"><LoadingStages step={stage} labels={['Outlining','Explaining','Adding examples','Finalising']}/><div className="mt-7"><Skeleton lines={7}/></div></Card>}
    {error&&<div role="alert" className="error-banner">{error}</div>}
    {saved&&<div role="status" className="success-banner"><CheckCircle2 size={18}/> Your notes are safely in My Library.</div>}
    <Card feature="notes" className="notes-reader-card"><NotesReader markdown={notes} title={topic}/></Card></div></div>
  </div>;
}

export function MockTests({ save }: { save: Persist }) {
  const [requirement, setRequirement] = useState('');
  const [count, setCount] = useState(10);
  const [kind, setKind] = useState('MCQ');
  const [difficulty, setDifficulty] = useState('Medium');
  const [test, setTest] = useState<GeneratedTest | null>(null);
  const [answers, setAnswers] = useState<Record<number,string>>({});
  const [result, setResult] = useState<{ score: number; total: number; feedback: { id: number; awarded: number; max: number; reason: string }[] } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [expanded,setExpanded]=useState<Record<number,boolean>>({});

  async function generate(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(''); setResult(null);
    try {
      const next = await postAI<GeneratedTest>('/api/gemini/generate-test', { topic: requirement, count, questionType: kind, difficulty });
      if (!Array.isArray(next.questions) || !next.questions.length) throw new Error('No questions returned.');
      setTest(next); setAnswers({});
      await save('TEST', next.title || requirement, next);
    } catch (err) { setError((err as Error).message); }
    finally { setBusy(false); }
  }

  async function submit() {
    if (!test) return;
    setBusy(true); setError('');
    try {
      // Hinglish: MCQ deterministic check hote hain; descriptive answers ko AI rubric evaluate karta hai.
      const graded = await postAI<{ score: number; total: number; feedback: { id: number; awarded: number; max: number; reason: string }[] }>('/api/gemini/grade-test', { questions: test.questions, answers });
      setResult(graded);
      await save('RESULT', `${test.title} — Attempt`, { test, answers, grading: graded, completedAt: new Date().toISOString() });
      if(graded.total>0&&graded.score/graded.total>=.8){void confetti({particleCount:130,spread:75,origin:{y:.5},colors:['#10b981','#34d399','#fbbf24','#a78bfa']});}
    } catch (err) { setError((err as Error).message); }
    finally { setBusy(false); }
  }

  const answeredCount=test?test.questions.filter(q=>Boolean(answers[q.id]?.trim())).length:0;
  return <div className={`space-y-6 ${kind==='MCQ'?'feature-generator':'feature-mock'}`}>
    <div className="section-heading"><IconTile feature="mock"><ClipboardCheck/></IconTile><div><Badge feature="mock">PRACTICE ARENA</Badge><h1>Practice with purpose.</h1><p>Custom interactive tests with insightful feedback, scoring and explanations.</p></div></div>
    <form onSubmit={generate} className="studio-card space-y-4 themed-card feature-generator">
      <label className="field-label">What should the test cover?<textarea required value={requirement} onChange={e => setRequirement(e.target.value)} rows={3} maxLength={1500} placeholder="e.g. 10 questions on SQL joins, WHERE, GROUP BY, and subqueries with increasing difficulty"/></label>
      <div className="grid sm:grid-cols-3 gap-4"><label className="field-label">Type<select value={kind} onChange={e => setKind(e.target.value)}><option value="MCQ">MCQ (default)</option><option value="SHORT">Short answer</option><option value="MIXED">Mixed</option></select></label><label className="field-label">Questions<input type="number" min={1} max={30} value={count} onChange={e => setCount(Math.max(1,Math.min(30,Number(e.target.value)||10)))}/></label><label className="field-label">Difficulty<select value={difficulty} onChange={e => setDifficulty(e.target.value)}><option>Easy</option><option>Medium</option><option>Hard</option></select></label></div>
      <Button feature="generator" disabled={busy||!requirement.trim()}>{busy?<Loader2 className="animate-spin"/>:<Sparkles size={18}/>} Generate & save test</Button>
    </form>
    {error && <p role="alert" className="error-banner">{error}</p>}
    {test && <div className="space-y-4"><Card feature="mock" className="sticky top-20 z-20"><div className="flex justify-between items-center gap-3"><div><h2 className="text-xl font-bold">{test.title}</h2><p className="text-sm text-slate-500">{test.questions.length} questions · {test.subject}</p></div><Badge feature="mock">{answeredCount}/{test.questions.length} answered</Badge></div><div className="test-progress"><span style={{width:`${100*answeredCount/test.questions.length}%`}}/></div></Card>
      {test.questions.map((q,i) => {const fb=result?.feedback.find(f=>f.id===q.id);const correct=fb?fb.awarded===fb.max:false;return <Card feature="mock" key={`${q.id}-${i}`} className={`question-card ${fb?(correct?'question-correct':'question-incorrect'):''}`}><div className="flex justify-between gap-3 items-start"><div className="flex items-start gap-3"><span className="question-number">{i+1}</span><h3 className="font-bold text-lg pt-1">{q.text}</h3></div><Badge feature="mock">{q.marks||1} marks</Badge></div>
        {q.type === 'MCQ' && q.options?.length ? <div className="grid sm:grid-cols-2 gap-3 mt-4">{q.options.map((option,j)=><label key={option} className={`answer-choice ${answers[q.id]===option?'selected':''}`}><input type="radio" name={`question-${q.id}`} checked={answers[q.id]===option} disabled={Boolean(result)} onChange={()=>setAnswers(p=>({...p,[q.id]:option}))}/><span className="answer-letter">{'ABCD'[j]||j+1}</span><span>{option}</span></label>)}</div> : <textarea rows={3} className="w-full mt-4" disabled={Boolean(result)} placeholder="Write your answer here" value={answers[q.id]||''} onChange={e=>setAnswers(p=>({...p,[q.id]:e.target.value}))}/>}
        {fb&&<div className="feedback-panel"><button className="w-full flex justify-between items-center gap-3" aria-expanded={Boolean(expanded[q.id])} onClick={()=>setExpanded(p=>({...p,[q.id]:!p[q.id]}))}><strong>{correct?'Correct':'Review answer'} · {fb.awarded}/{fb.max} marks</strong><ChevronDown size={18}/></button>{expanded[q.id]&&<p className="text-sm mt-3 leading-relaxed">{fb.reason||q.explanation}</p>}</div>}
      </Card>})}
      {!result?<Button feature="mock" disabled={busy} onClick={submit}>{busy?'Checking answers…':'Submit for evaluation'}</Button>:<Card feature="mock" className="result-card"><div className="score-ring" style={{background:`conic-gradient(#10b981 ${result.total?result.score/result.total*100:0}%,#d1fae5 0)`}}><div><strong>{result.score}/{result.total}</strong><span>your score</span></div></div><div><h2 className="text-2xl font-extrabold">{result.total>0&&result.score/result.total>=.8?'Excellent work!':'Keep progressing!'}</h2><p className="text-slate-500 text-sm my-3">Your results are saved. Descriptive grading is AI-assisted and may need human review.</p><Button feature="mock" variant="secondary" onClick={()=>{setTest(null);setResult(null);}}>Start another test</Button></div></Card>}
    </div>}
  </div>;
}
