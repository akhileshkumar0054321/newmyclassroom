import React, { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, Mic, MicOff, MonitorUp, Phone, PhoneOff, Video } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Badge, Button, Card, EmptyState, IconTile } from './UI';

type Profile = { id:string; uid:string; display_name:string };
type Invite = { id:string; caller_id:string; callee_id:string; status:string; created_at:string };

export function Meetings({me}:{me:Profile}) {
  const [uid,setUid]=useState(''); const [invites,setInvites]=useState<Invite[]>([]);
  const [active,setActive]=useState<Invite|null>(null); const [message,setMessage]=useState('');
  const [mic,setMic]=useState(true);const [camera,setCamera]=useState(true);
  const localVideo=useRef<HTMLVideoElement>(null);const remoteVideo=useRef<HTMLVideoElement>(null);
  const localStream=useRef<MediaStream|null>(null);const peer=useRef<RTCPeerConnection|null>(null);
  const seenSignals=useRef<Set<number>>(new Set());const candidates=useRef<RTCIceCandidateInit[]>([]);
  const activeRef=useRef<Invite|null>(null);

  async function refresh(){const {data,error}=await supabase.from('meeting_invites').select('*').order('created_at',{ascending:false}).limit(30);if(error)setMessage(error.message);else setInvites(data||[]);}
  useEffect(()=>{void refresh();const channel=supabase.channel(`my-meetings-${me.id}`).on('postgres_changes',{event:'*',schema:'public',table:'meeting_invites'},()=>void refresh()).subscribe();return()=>{void supabase.removeChannel(channel);cleanup();};},[me.id]);

  function cleanup(){peer.current?.close();peer.current=null;localStream.current?.getTracks().forEach(t=>t.stop());localStream.current=null;if(localVideo.current)localVideo.current.srcObject=null;if(remoteVideo.current)remoteVideo.current.srcObject=null;activeRef.current=null;setActive(null);seenSignals.current.clear();candidates.current=[];}
  async function hangup(){if(activeRef.current)await supabase.rpc('end_meeting',{target_id:activeRef.current.id});cleanup();void refresh();}

  async function createCall(e:React.FormEvent){e.preventDefault();setMessage('');const {data,error}=await supabase.from('profiles').select('id').eq('uid',uid.trim().toUpperCase()).maybeSingle();if(error||!data)return setMessage(error?.message||'Student UID not found');if(data.id===me.id)return setMessage('You cannot call yourself');const result=await supabase.from('meeting_invites').insert({caller_id:me.id,callee_id:data.id}).select().single();if(result.error)setMessage(result.error.message);else{setMessage('Invitation sent. Waiting for the other student to accept.');setUid('');await refresh();}}

  async function accept(invite:Invite){setMessage('');try{await initialize(invite,false);const {error}=await supabase.from('meeting_invites').update({status:'accepted'}).eq('id',invite.id);if(error)throw error;await refresh();}catch(e){cleanup();setMessage((e as Error).message);}}
  async function decline(invite:Invite){const {error}=await supabase.from('meeting_invites').update({status:'declined'}).eq('id',invite.id);if(error)setMessage(error.message);else await refresh();}

  async function signal(meetingId:string,payload:object){const {error}=await supabase.from('meeting_signals').insert({meeting_id:meetingId,sender_id:me.id,payload});if(error)throw error;}

  async function handleSignal(row:any){if(row.sender_id===me.id||seenSignals.current.has(row.id)||!peer.current)return;seenSignals.current.add(row.id);
    const pc=peer.current;const payload=row.payload;
    try{
      if(payload.type==='offer'){await pc.setRemoteDescription(new RTCSessionDescription(payload.description));const answer=await pc.createAnswer();await pc.setLocalDescription(answer);await signal(row.meeting_id,{type:'answer',description:answer});}
      if(payload.type==='answer')await pc.setRemoteDescription(new RTCSessionDescription(payload.description));
      if(payload.type==='candidate'){if(pc.remoteDescription)await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));else candidates.current.push(payload.candidate);}
      if(pc.remoteDescription&&candidates.current.length){for(const c of candidates.current)await pc.addIceCandidate(new RTCIceCandidate(c));candidates.current=[];}
    }catch(e){setMessage(`Call signaling failed: ${(e as Error).message}`);}
  }

  async function initialize(invite:Invite,isCaller:boolean){
    // Hinglish: WebRTC camera/mic streams peers ke beech direct jaati hain. Database sirf signaling rakhta hai.
    if(peer.current)return;
    const stream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});localStream.current=stream;
    const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});peer.current=pc;
    stream.getTracks().forEach(track=>pc.addTrack(track,stream));
    pc.ontrack=event=>{if(remoteVideo.current)remoteVideo.current.srcObject=event.streams[0];};
    pc.onicecandidate=event=>{if(event.candidate)void signal(invite.id,{type:'candidate',candidate:event.candidate.toJSON()}).catch(e=>setMessage(e.message));};
    pc.onconnectionstatechange=()=>{if(pc.connectionState==='failed')setMessage('Connection failed. A TURN server may be required on this network.');};
    setActive(invite);activeRef.current=invite;setMic(true);setCamera(true);
    setTimeout(()=>{if(localVideo.current)localVideo.current.srcObject=stream;},0);
    const {data}=await supabase.from('meeting_signals').select('*').eq('meeting_id',invite.id).order('id');
    for(const row of data||[])await handleSignal(row);
    if(isCaller){const offer=await pc.createOffer();await pc.setLocalDescription(offer);await signal(invite.id,{type:'offer',description:offer});}
  }

  useEffect(()=>{const pending=invites.find(i=>i.caller_id===me.id&&i.status==='accepted'&&!peer.current);if(pending)void initialize(pending,true).catch(e=>setMessage(e.message));const ended=invites.find(i=>i.id===activeRef.current?.id&&i.status==='ended');if(ended)cleanup();},[invites,me.id]);
  useEffect(()=>{if(!active)return;const channel=supabase.channel(`signaling-${active.id}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'meeting_signals',filter:`meeting_id=eq.${active.id}`},event=>void handleSignal(event.new)).subscribe();return()=>{void supabase.removeChannel(channel);};},[active?.id]);
  function toggleMic(){localStream.current?.getAudioTracks().forEach(t=>t.enabled=!mic);setMic(!mic);}
  function toggleCamera(){localStream.current?.getVideoTracks().forEach(t=>t.enabled=!camera);setCamera(!camera);}
  async function shareScreen(){try{const screen=await navigator.mediaDevices.getDisplayMedia({video:true});const track=screen.getVideoTracks()[0];const sender=peer.current?.getSenders().find(s=>s.track?.kind==='video');if(!sender)return;const original=localStream.current?.getVideoTracks()[0];await sender.replaceTrack(track);if(localVideo.current)localVideo.current.srcObject=screen;track.onended=()=>{void sender.replaceTrack(original||null);if(localVideo.current)localVideo.current.srcObject=localStream.current;};}catch(e){setMessage((e as Error).message);}}

  return <div className="space-y-6 feature-meetings"><div className="section-heading"><IconTile feature="meetings"><Video/></IconTile><div><Badge feature="meetings">FACE-TO-FACE LEARNING</Badge><h1>Study feels closer here.</h1><p>Invite classmates by UID for a private video conversation or screen-sharing session.</p></div></div>
    <form onSubmit={createCall} className="studio-card themed-card flex flex-wrap gap-3 items-end"><label className="field-label flex-1">Student UID<input required value={uid} onChange={e=>setUid(e.target.value)} placeholder="Enter the other student's unique ID"/></label><Button feature="meetings"><Phone size={17}/> Invite to meeting</Button></form>
    {message&&<p role="status" className="studio-card text-sm">{message}</p>}
    <Card feature="meetings"><h3 className="font-bold mb-3">Meeting requests</h3>{invites.filter(i=>!['ended','declined'].includes(i.status)).map(invite=><div key={invite.id} className="flex flex-wrap justify-between items-center gap-3 py-3 border-b last:border-0" style={{borderColor:'var(--border)'}}><span className="text-sm">{invite.caller_id===me.id?'Outgoing':'Incoming'} · <Badge feature="meetings">{invite.status}</Badge> · {new Date(invite.created_at).toLocaleString()}</span><div className="flex gap-2">{invite.callee_id===me.id&&invite.status==='pending'&&<><Button feature="meetings" onClick={()=>accept(invite)}>Accept</Button><Button feature="meetings" variant="secondary" onClick={()=>decline(invite)}>Decline</Button></>}{invite.id===active?.id&&<Button variant="danger" onClick={hangup}><PhoneOff size={17}/> End</Button>}</div></div>)}{!invites.length&&<EmptyState feature="meetings" icon={<Video/>} title="No invitations yet" description="Enter a student UID above to begin a private study meeting."/>}</Card>
    {active&&<Card feature="meetings" className="space-y-5"><div className="grid md:grid-cols-2 gap-4"><div className="relative"><video ref={remoteVideo} autoPlay playsInline className="meeting-video"/><Badge feature="meetings" className="absolute bottom-3 left-3">Classmate</Badge></div><div className="relative"><video ref={localVideo} autoPlay muted playsInline className="meeting-video"/><Badge feature="meetings" className="absolute bottom-3 left-3">You</Badge></div></div><div className="meeting-controls"><Button feature="meetings" variant="secondary" aria-label={mic?'Mute microphone':'Unmute microphone'} title={mic?'Mute':'Unmute'} onClick={toggleMic}>{mic?<Mic/>:<MicOff/>}</Button><Button feature="meetings" variant="secondary" aria-label={camera?'Turn camera off':'Turn camera on'} title={camera?'Camera off':'Camera on'} onClick={toggleCamera}>{camera?<Camera/>:<CameraOff/>}</Button><Button feature="meetings" variant="secondary" aria-label="Share screen" title="Share screen" onClick={shareScreen}><MonitorUp/></Button><Button variant="danger" aria-label="Hang up" title="Hang up" onClick={hangup}><PhoneOff/></Button></div><p className="text-xs" style={{color:'var(--muted)'}}>Calls require HTTPS and camera/mic permissions. STUN-only connections may need TURN on restrictive networks.</p></Card>}
  </div>;
}
